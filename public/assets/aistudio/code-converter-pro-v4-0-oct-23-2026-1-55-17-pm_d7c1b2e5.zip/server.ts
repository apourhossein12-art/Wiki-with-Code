/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateDeterministicConversion } from './src/utils/converter-utils';
import { ConversionConfig, ProjectFile } from './src/types';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '15mb' }));

// Initialize GoogleGenAI client (Server-side only)
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// API Route for multi-file conversion
app.post('/api/convert-project', async (req, res) => {
  try {
    const { files, config }: { files: ProjectFile[]; config: ConversionConfig } = req.body;

    if (!files || !Array.isArray(files) || files.length === 0) {
      return res.status(400).json({ error: 'No files provided for conversion' });
    }

    // Check if GEMINI_API_KEY is configured and valid
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey === 'undefined' || apiKey.trim() === '') {
      console.log('[Server] No valid GEMINI_API_KEY found in environment. Using deterministic engine.');
      const result = generateDeterministicConversion(files, config);
      return res.json(result);
    }

    const filesSummary = files
      .map(
        (f) => `### File: ${f.path}
\`\`\`${f.language || 'text'}
${f.content}
\`\`\``
      )
      .join('\n\n');

    const prompt = `You are Code Converter Pro v4.0, an elite principal engineer specializing in large-scale code migrations and multi-file framework transformations.

Convert this entire multi-file project from "${config.sourceStack}" to "${config.targetStack}".
Architectural structure: ${config.architecture} (isMonorepo: ${config.architecture === 'monorepo'})
TypeScript: ${config.useTypeScript ? 'Enabled' : 'Disabled'}
State strategy: ${config.stateStrategy}

Strict conversion instructions:
1. Understand and preserve relationships between files (imports, shared types, props, hooks/stores).
2. Redesign folder structure according to the target framework's best practices (e.g. if monorepo, packages/ui, packages/shared, apps/web).
3. If converting React -> Vue 3, use <script setup lang="ts"> and Pinia. If Vue -> React, use React 19 functional hooks. If Blade -> Inertia, place under resources/js/Pages and resources/js/Components.
4. Output strict JSON matching the schema with:
   - projectAnalysis: summary of source architecture, relationships, shared modules, key decisions
   - recommendedTargetStructure: isMonorepo, treeDescription, fileMapping
   - convertedFiles: array of { path, originalPath, content, language, explanation, status }
   - dependencyUpdates: packageJson additions/removals/scripts and notes
   - migrationNotes: array of important gotchas

Here are the source files:
${filesSummary}`;

    const startTime = Date.now();

    try {
      const generatePromise = ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              projectAnalysis: {
                type: Type.OBJECT,
                properties: {
                  sourceSummary: { type: Type.STRING },
                  relationships: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        from: { type: Type.STRING },
                        to: { type: Type.STRING },
                        type: { type: Type.STRING },
                        description: { type: Type.STRING },
                      },
                      required: ['from', 'to', 'type'],
                    },
                  },
                  sharedModules: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  keyDecisions: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ['sourceSummary', 'relationships', 'sharedModules', 'keyDecisions'],
              },
              recommendedTargetStructure: {
                type: Type.OBJECT,
                properties: {
                  isMonorepo: { type: Type.BOOLEAN },
                  treeDescription: { type: Type.STRING },
                  fileMapping: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        source: { type: Type.STRING },
                        target: { type: Type.STRING },
                        reason: { type: Type.STRING },
                      },
                      required: ['source', 'target', 'reason'],
                    },
                  },
                },
                required: ['isMonorepo', 'treeDescription', 'fileMapping'],
              },
              convertedFiles: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    path: { type: Type.STRING },
                    originalPath: { type: Type.STRING },
                    content: { type: Type.STRING },
                    language: { type: Type.STRING },
                    explanation: { type: Type.STRING },
                    status: { type: Type.STRING },
                  },
                  required: ['path', 'content', 'language', 'explanation'],
                },
              },
              dependencyUpdates: {
                type: Type.OBJECT,
                properties: {
                  notes: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ['notes'],
              },
              migrationNotes: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              'projectAnalysis',
              'recommendedTargetStructure',
              'convertedFiles',
              'dependencyUpdates',
              'migrationNotes',
            ],
          },
        },
      });

      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('AI conversion response timed out after 8 seconds')), 8000)
      );

      const response: any = await Promise.race([generatePromise, timeoutPromise]);
      const responseText = response.text || '';
      const parsed = JSON.parse(responseText);
      parsed.engine = 'gemini-3.8-flash';
      parsed.latencyMs = Date.now() - startTime;
      parsed.targetStack = config.targetStack;
      parsed.convertedAt = new Date().toISOString();
      return res.json(parsed);
    } catch (aiError: any) {
      console.warn('[Server] Gemini call warning or rate limit, falling back to deterministic engine:', aiError?.message || aiError);
      const fallbackResult = generateDeterministicConversion(files, config);
      fallbackResult.latencyMs = Date.now() - startTime;
      return res.json(fallbackResult);
    }
  } catch (err: any) {
    console.error('[Server] Convert Project Error:', err);
    res.status(500).json({ error: err.message || 'Internal server error during project conversion' });
  }
});

// Vite middleware integration for full-stack dev
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[Server] Code Converter Pro v4.0 running at http://localhost:${PORT}`);
  });
}

startServer();
